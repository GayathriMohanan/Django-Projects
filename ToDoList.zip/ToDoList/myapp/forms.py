from django import forms  

class registrationForm(forms.Form):
    username=forms.CharField(max_length=50,required=True)
    password=forms.CharField(max_length=10,required=True)
    
class loginForm(forms.Form):
    l_username=forms.CharField(max_length=50,required=True)
    l_password=forms.CharField(max_length=10,required=True)

class newTaskForm(forms.Form):
    tname=forms.CharField(max_length=100,required=True)