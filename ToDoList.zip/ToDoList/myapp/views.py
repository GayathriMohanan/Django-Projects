from django.shortcuts import render
from .forms import *
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login, authenticate,logout
from django.contrib.auth.decorators import login_required

# Create your views here.

def register(request):
    reg_form=registrationForm(request.POST)
    if request.method=='POST' and reg_form.is_valid():
        name=reg_form.cleaned_data['username']
        password=reg_form.cleaned_data['password']
        obj=User()
        user_email=User.objects.filter(email=name).first()
        if user_email is None:
            obj.username=name
            obj.email=name
            obj.set_password(password)
            obj.save()
        else:
            return render(request,'login.html',{"msg":"Already Registered! Please login"})
        
    return render(request,'register.html')

def login(request):
    login_form=loginForm(request.POST or None)
    if request.method=='POST' and login_form.is_valid():
        name=login_form.cleaned_data['l_username']
        password=login_form.cleaned_data['l_password']
        user=authenticate(request,username=name,password=password)
        if user is not None:
            auth_login(request,user)
            tasks=Task.objects.filter(userId=user)
            return render(request,'task_list.html',{"tasks":tasks})
            
        else:
            return render(request,'register.html',{"msg":"Please register"})
            
    return render(request,'login.html',{"form":login_form})

@login_required
def taskList(request):
    user=request.user
    tasks=Task.objects.filter(userId=user)
    return render(request,'task_list.html',{"tasks":tasks})

@login_required
def addNewTask(request):
    taskform=newTaskForm(request.POST or None)
    if request.method=='POST' and taskform.is_valid():
        tname=taskform.cleaned_data['tname']
        user=request.user
        task=Task(taskName=tname,userId=user)
        task.save()
        tasks=Task.objects.filter(userId=user)
        return render(request,'task_list.html',{"tasks":tasks})
    
    return render(request,'new_task.html',{"form":taskform})

@login_required
def deleteTask(request,id):
    task=Task.objects.get(id=id)
    task.delete()
    user=request.user
    tasks=Task.objects.filter(userId=user)
    return render(request,'task_list.html',{"tasks":tasks})


def logoutUser(request):
    logout(request)
    return render(request,'login.html')
