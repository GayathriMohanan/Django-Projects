from django.urls import path
from . import views
urlpatterns=[
    path('',views.login,name='login_page'),
    path('register/',views.register,name='register_page'),
    path('tasklist/',views.taskList,name='tasks_page'),
    path('addnewtask/',views.addNewTask,name='addNewTask_page'),
    path('deleteTask/<int:id>/',views.deleteTask,name='delete_page'),
    path('logout/',views.logoutUser,name='logout'),
]